from django.contrib import admin
from .models import Flipkart_Api


admin.site.register(Flipkart_Api)

# Register your models here.
